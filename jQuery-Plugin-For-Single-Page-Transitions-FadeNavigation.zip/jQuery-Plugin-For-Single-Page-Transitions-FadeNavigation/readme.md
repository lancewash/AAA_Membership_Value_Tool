# jQuery FadeNavigation


## 1. Iniciando

### 1.1 Dependência
Inclua este plugin após o jQuery
```html
<script src="path/to/jquery.min.js"></script>
<script src="path/to/jquery.fadenavigation.min.js"></script>
```

### 1.2 Estrutura
Crie suas páginas com classe page dentro do container que preferir
```html
<div id="seu-container">
  <div class="page"></div>
  <div class="page"></div>
  <div class="page"></div>
  <div class="page"></div>
</div>
```

### 1.3 Estilo
Recomendo que coloque apenas um
```css
.page{ display: none; }
```

### 1.4 Instancia
```js
$('#seu-container').fadeNavigation();
```

## 2. Navegando

### 2.1 navTo
Crie a.navTo para navegar pelas páginas, onde href = (id da página destino)
```html
<a href="#home" class="navTo">Vou para a home</a>
```

### 2.2 navToNext
Crie a.navToNext para navegar para a próxima página
```html
<a href="#" class="navToNext">Vou para a próxima</a>
```

### 2.3 navToPrev
Cria a.navToPrev para navegar para a página anterior
```html
<a href="#" class="navToPrev">Vou para a anterior</a>
```

## 3. Muito obrigado :D
Qualquer dúvida olhe o exemplo no repositório, ou fale comigo.
